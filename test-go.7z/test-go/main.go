package main

import "fmt"

func log(all ...interface{}) {
	fmt.Printf("%v \n", all)
}

func main() {
	__main()
}
