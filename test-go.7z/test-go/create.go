package main

func __main() {
    var taoer = map[string]string{"first": "gao", "second": "shuo"}
    log("map", taoer)
}
